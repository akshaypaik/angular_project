export class constants{
   public static ticketPattern = '^([a-zA-Z]{3}[0-9]{4})$';
   public static emailPattern = '[a-zA-z]+@[a-zA-Z]+.[a-zA-z]+';
   public static pidPatttern = '^([A-Z]{1}[0-9]{6})$';
}