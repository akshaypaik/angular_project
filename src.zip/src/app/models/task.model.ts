export class taskModel{
    taskOwner: string;
    aura: string;
    ube: string;
    content: string;
    access: string;
    blacklisting: string;
    catalog: string;
}