export interface loginTimeTableModel{
    loginTime: number;
    status: string;
}