import { usersModel } from './users.model';

export class userListModel{
    userData : Array<usersModel>;
}